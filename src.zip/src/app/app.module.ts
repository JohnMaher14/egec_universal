import { NgModule } from '@angular/core';
import { BrowserModule, TransferState } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { ReactiveFormsModule } from '@angular/forms';
import { TranslateLoader, TranslateModule } from '@ngx-translate/core';
import { HttpClient, HttpClientModule} from '@angular/common/http'
import ar from '@angular/common/locales/ar';

import en from '@angular/common/locales/en';
import { registerLocaleData } from '@angular/common';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
// Angular material
import { AngularMaterialModule } from './material.module';
import { CarouselModule } from 'ngx-owl-carousel-o';
import { SwiperModule } from "swiper/angular";
// decelaration
import { HomeComponent } from './pages/content/home/home.component';
import { NavbarComponent } from './pages/shared/navbar/navbar.component';
import { FooterComponent } from './pages/shared/footer/footer.component';
import { NotfoundComponent } from './pages/shared/notfound/notfound.component';
import { AboutUsComponent } from './pages/content/about-us/about-us.component';
import { CountUpModule } from "ngx-countup";
import { NgwWowModule } from "ngx-wow";
import { NgxSkeletonLoaderModule } from 'ngx-skeleton-loader';
import { translateBrowserLoaderFactory } from './shared_function/translate-browser.loader';
registerLocaleData(ar)
registerLocaleData(en)

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    NavbarComponent,
    FooterComponent,
    NotfoundComponent,
    AboutUsComponent
  ],
  imports: [
    BrowserModule.withServerTransition({ appId: 'serverApp' }),
    AppRoutingModule,
    NgbModule,
    ReactiveFormsModule,
    HttpClientModule,
    AngularMaterialModule,

    BrowserAnimationsModule,
    CarouselModule,
    CountUpModule,
    NgwWowModule,
    NgxSkeletonLoaderModule,
    TranslateModule.forRoot({
      defaultLanguage: 'ar',
      loader: {
        provide: {
          TranslateLoader,
          TransferState}
          ,
        useFactory: translateBrowserLoaderFactory,
        deps: [HttpClient, TransferState]
      }
    })
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
// export function HttpLoaderFactory(_HttpClient:HttpClient){
//   return new TranslateHttpLoader(_HttpClient , './assets/i18n/','.json')
// }
selec
