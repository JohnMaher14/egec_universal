import { DOCUMENT, isPlatformBrowser } from '@angular/common';
import { Component, Inject, OnInit, PLATFORM_ID } from '@angular/core';
import { Title, Meta } from '@angular/platform-browser';
import { TranslateService } from '@ngx-translate/core';
import { OwlOptions } from 'ngx-owl-carousel-o';
import { NgwWowService } from 'ngx-wow';
import { HomeService } from 'src/app/services/home.service';
import { environment } from 'src/environments/environment';
// import {  } from "";
@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss'],
})
export class HomeComponent implements OnInit {
  loading: boolean = false;
  destinations: any[] = [];
  universities: any[] = [];
  changeUniversities: any[] = [];
  userReviews: any[] = [];
  blogs: any[] = [];
  blogImage: string = `${environment.imageUrl}blogs`;
  reviewImage: string = `${environment.imageUrl}contact/`;
  currentLanguage: any;
  currentLang: any;
  constructor(
    public _TranslateService: TranslateService,
    private _Title: Title,
    private _HomeService: HomeService,
    @Inject(DOCUMENT) private document: Document,
    @Inject(PLATFORM_ID) private platformId: any,

    private _Meta: Meta
  ) {}
  showcurrentLanguage(language: any) {
    this._TranslateService.use(language);
    localStorage.setItem('currentLanguage', language);
  }
  ngOnInit(): void {

      this.showHomeData();
      this.showReviews();
      this.showBlogs();
    this.currentLang = localStorage.getItem('currentLanguage') || 'ar';
    this._TranslateService.use(this.currentLang);
    this._TranslateService.onLangChange.subscribe((language: any) => {
      if (language.lang == 'en') {
        this._Title.setTitle(`${environment.title}Home`);
      } else if (language.lang == 'ar') {
        this._Title.setTitle(`${environment.title}الصفحة الرئيسية`);
      }
      this.currentLanguage = this._TranslateService.currentLang;
    });
    this._Meta.addTags([
      { name: 'description', content: 'tes test tsh' },
      { name: 'description', content: 'tes2 test tsh' },
      { name: 'description', content: 'tes3 test tsh' },
      { name: 'description', content: 'tes4 test tsh' },
      { name: 'description', content: 'tes5 test tsh' },
    ]);
  }

  testimonials: OwlOptions = {
    loop: true,
    // center: true,
    dots: true,
    margin: 30,
    autoplay: true,
    navSpeed: 700,
    navText: [
      `<i class="fa fa-angle-left"></i>`,
      `<i class="fa fa-angle-right"></i>`,
    ],

    nav: true,
    responsive: {
      0: {
        items: 1,
      },
      400: {
        items: 1,
      },

      940: {
        items: 2,
      },
      1600: {
        items: 2,
      },
    },
  };
  testimonialsAr: OwlOptions = {
    loop: true,
    // center: true,
    dots: true,
    autoHeight: true,

    margin: 30,
    autoplay: true,
    rtl: true,
    navSpeed: 700,
    navText: [
      `<i class="fa fa-angle-right"></i>`,
      `<i class="fa fa-angle-left"></i>`,
    ],

    nav: true,
    responsive: {
      0: {
        items: 1,
      },
      400: {
        items: 1,
      },

      940: {
        items: 2,
      },
      1600: {
        items: 2,
      },
    },
  };
  showHomeData() {
    this._HomeService.getHomeData().subscribe((response) => {
      this.destinations = response.destinations;
      this.universities = response.university;
    });
  }
  showReviews() {
    this.loading = true;

    this._HomeService.getTestominals().subscribe((response) => {
      this.userReviews = response.reviews;
      this.loading = false;
    });
  }
  showBlogs() {
    this.loading = true;

    this._HomeService.getBlogs().subscribe((response) => {
      this.blogs = response.blogs;
      this.loading = false;
    });
  }
  onChangeDestination(event: any) {
    console.log(event.target.value);
    const universitiesArray = this.universities.filter((universities: any) => {
      return universities.destination_id == event.target.value;
    });
    this.changeUniversities = universitiesArray;
  }
}
